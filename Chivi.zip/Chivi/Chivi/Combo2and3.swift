//
//  Combo2and3.swift
//  Chivi
//
//  Created by Abraham Morales Arroyo on 11/2/23.
//

import SwiftUI

struct Combo2and3: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    Combo2and3()
}

//