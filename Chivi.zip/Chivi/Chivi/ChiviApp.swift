//
//  ChiviApp.swift
//  Chivi
//
//  Created by Abraham Morales Arroyo on 10/21/23.
//

import SwiftUI

@main
struct ChiviApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
